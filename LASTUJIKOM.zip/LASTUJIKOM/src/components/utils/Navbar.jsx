import React, { useState } from 'react';
import { useLocation } from 'react-router-dom';
import '../css/navbar.css';
import { NavLink } from 'react-router-dom';

const Navbar = () => {
  const [isOpen, setIsOpen] = useState(false);
  const location = useLocation();

  const toggleMenu = () => {
    setIsOpen(!isOpen);
  };

  const hideNavbarRoutes = ['/', '/Foods/admin', `/edit/`];

  const shouldHideNavbar = hideNavbarRoutes.includes(location.pathname);

  if (shouldHideNavbar) {
    return null;
  }

  return (
    <nav className="navbar">
      <h1>Travelo</h1>

      <button className={`hamburger-btn ${isOpen ? 'active' : ''}`} onClick={toggleMenu} aria-label="Toggle Menu">
        <span className="bar"></span>
        <span className="bar"></span>
        <span className="bar"></span>
      </button>

      <ul className={`nav-links ${isOpen ? 'open' : ''}`}>
        <div className="foods">
          <li>
            <NavLink to="Home">Home</NavLink>
          </li>
          <li>
            <NavLink to="Pariwisata">Pariwisata</NavLink>
          </li>
          <li>
            <NavLink to="Contact">Contact</NavLink>
          </li>
        </div>
      </ul>
    </nav>
  );
};

export default Navbar;
